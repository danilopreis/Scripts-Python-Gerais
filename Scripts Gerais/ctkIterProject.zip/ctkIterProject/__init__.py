from mainFrameLogin import AppGPLogin


def __init__(self):
    AppGPLogin()
