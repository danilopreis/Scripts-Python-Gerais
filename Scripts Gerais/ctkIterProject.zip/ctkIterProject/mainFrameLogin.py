from customtkinter import *
from mainFrameMenu import AppGPMenu
import customtkinter
from PIL import Image


class AppGPLogin(CTk):
    def __init__(self):
        super().__init__()
        self.initial_window()

    def initial_window(self):
        self.geometry("700x400")
        self.title("Faça seu Login")
        self.resizable(False, False)
        main_frame = CTkFrame(self, fg_color=self.cget("bg"))
        main_frame.grid(row=0, column=0, padx=30, pady=30)

        # Login Window title

        my_image = customtkinter.CTkImage(dark_image=Image.open("logoTeste.png"), size=(300, 150))
        image_label = customtkinter.CTkLabel(master=main_frame, image=my_image, text="")
        image_label.grid(row=3, column=0, padx=(0, 50), pady=(0, 20))

        # Username label and entry box
        user_label = CTkLabel(master=main_frame, text="Username:")
        user_label.grid(row=2, column=2, sticky="w", pady=(0, 0))
        self.user_entry = CTkEntry(master=main_frame)
        self.user_entry.grid(row=2, column=3, pady=(0, 10), padx=10)

        # Password label and entry box
        pass_label = CTkLabel(master=main_frame, text="Password:")
        pass_label.grid(row=3, column=2, sticky="w", pady=(0, 0))
        self.pass_entry = CTkEntry(master=main_frame, show="*")
        self.pass_entry.grid(row=3, column=3, pady=(0, 10), padx=10)

        # Login button
        login_button = CTkButton(master=main_frame, text="Login", command=self.button_login_function)
        login_button.grid(row=5, column=3, pady=(0, 20), sticky="e")

        # Exit button
        exit_button = CTkButton(master=main_frame, text="Sair", command=self.button_exit_function)
        exit_button.grid(row=5, column=2, pady=(0, 20), sticky="e")

    def valida_login(self):
        if self.user_entry.get() == "admin" and self.pass_entry.get() == "12345":
            self.result = "Login Success"
        else:
            self.result = "Login Fail"

    def button_login_function(self):
        self.valida_login()
        if self.result == "Login Success":
            self.destroy()
            print('Login Success')
            AppGPMenu().mainloop()
        else:
            print('Suas credenciais são invalidas!')

    def button_exit_function(self):
        self.destroy()
        print('Exit Success')


app = AppGPLogin()
app.mainloop()
