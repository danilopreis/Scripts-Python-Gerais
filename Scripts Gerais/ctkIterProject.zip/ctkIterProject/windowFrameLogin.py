import customtkinter as ctk
from customtkinter import *
from PIL import Image
import sqlite3


class BackendLogin:
    def connect_db(self):
        self.conn = sqlite3.connect("sistema_gp_fusiontec.db")
        self.cursor = self.conn.cursor()

    def desconnect_db(self):
        self.conn.close()

    def verify_login(self):
        self.username_login = self.username_entry.get()
        self.password_login = self.password_entry.get()
        print("123")
        self.clear_entry_login()


class AppGPLogin(ctk.CTk, BackendLogin):
    def __init__(self):
        super().__init__()
        self.config_initial_window()
        self.login_window()

    # Configurações da Janela principal
    def config_initial_window(self):
        self.geometry("700x260")
        self.title("Tela de Login - Sistema GP Fusiontec")
        self.resizable(False, False)

    # Elementos da tela de login
    def login_window(self):
        self.img = ctk.CTkImage(dark_image=Image.open("logoTeste.png"), size=(300, 200))
        self.lb_img = ctk.CTkLabel(self, text=None, image=self.img)
        self.lb_img.grid(row=1, column=0, padx=10)

        # Titulo principal da tela de login
        self.lb_title = ctk.CTkLabel(self, text="Digite suas credenciais para acessar o sistema!\n Qualquer dúvida,\n por gentileza contate o Administrador!", font=("Century Gothic Bold", 14))
        self.lb_title.grid(row=0, column=0, pady=10, padx=10)

        # Frame do formulario de Login
        self.frame_login = ctk.CTkFrame(self, width=350, height=350)
        self.frame_login.place(x=350, y=10)

        # Widgets da Frame Formulario de Login
        self.lb_title = ctk.CTkLabel(self.frame_login, text="Faça o seu Login", font=("Century Gothic bold", 22))
        self.lb_title.grid(row=0, column=0, padx=10, pady=10)

        self.username_entry = ctk.CTkEntry(self.frame_login, width=300, placeholder_text="Digite seu usuario...", font=("Century Gothic bold", 16), corner_radius=15)
        self.username_entry.grid(row=1, column=0, padx=10, pady=10)

        self.password_entry = ctk.CTkEntry(self.frame_login, width=300, placeholder_text="*********", show="*", font=("Century Gothic bold", 16), corner_radius=15)
        self.password_entry.grid(row=2, column=0, padx=10, pady=10)

        self.view_enable_password = ctk.CTkCheckBox(self.frame_login, text="Exibir a senha", font=("Century Gothic bold", 14), corner_radius=20)
        self.view_enable_password.grid(row=3, column=0, padx=10, pady=10)

        self.btn_login = ctk.CTkButton(self.frame_login, width=300, text="Fazer Login".upper(), font=("Century Gothic bold", 16), corner_radius=15, command=self.verify_login())
        self.btn_login.grid(row=4, column=0, padx=10, pady=10)

    # Limpar campos do formulario de Login
    def clear_entry_login(self):
        self.username_entry.delete(0, END)
        self.password_entry.delete(0, END)


if __name__ == "__main__":
    app = AppGPLogin()
    app.mainloop()
